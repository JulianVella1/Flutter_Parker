import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:parker/models/parking_spot.dart';

class ParkingStorage {
  static const String parkingSpotsKey = 'parking_spots';

  static Future<void> saveParkingSpots(List<ParkingSpot> spots) async {
    final prefs = await SharedPreferences.getInstance();
    final spotsJson = spots.map((spot) => jsonEncode(spot.toMap())).toList();
    await prefs.setStringList(parkingSpotsKey, spotsJson);
  }

  static Future<List<ParkingSpot>> loadParkingSpots() async {
    final prefs = await SharedPreferences.getInstance();
    final spotsJson = prefs.getStringList(parkingSpotsKey) ?? [];
    return spotsJson
        .map((spotString) => ParkingSpot.fromMap(jsonDecode(spotString)))
        .toList();
  }
}
